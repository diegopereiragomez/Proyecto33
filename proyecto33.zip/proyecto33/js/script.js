
async function cargarLibros() {
    try {
        //lectura asincrona del archivo json donde estan los datos
        const respuesta = await fetch('./data/libros.json');
        const libros = await respuesta.json();
       
        //Creacion del elemento listado libros donde se mostrara la matriz de articulos
        const listadolibros = document.getElementById('listado-libros');

        libros.forEach(libro => {
            //creacion de cada uno de los articulos desde el archivo json
            const artigo = document.createElement('articulo');
            const portada = document.createElement('img');
            const titulo = document.createElement('h3');
            const autor = document.createElement('p');
            const descripcion = document.createElement('p');

            //introducion de los datos en el articulo
            portada.src = `./img/${libro.imagen}`;
            portada.alt = `imagen articulo`;
            titulo.textContent = libro.producto;
            autor.innerHTML = `<strong class="parrafo">Precio: </strong>${libro.precio}`;
            descripcion.textContent = libro.categoria;

            //introduccion de cada articulo en la matriz
            artigo.appendChild(portada);
            artigo.appendChild(titulo);
            artigo.appendChild(autor);
            artigo.appendChild(descripcion);

            artigo.addEventListener("click", () => {
                mostrarNodal(libro);
            });
            listadolibros.appendChild(artigo);
        });
    }
    catch (error) {
        console.error("error al cargar la pagina".error);
    }
}

function mostrarNodal(libro) {
    //creacion de una ventana modal para poder ver mas detalladamente el articulo
    const nodal = document.getElementById('nodal');
    const nodaltitulo = document.getElementById('nodal-titulo');
    const nodalportada = document.getElementById('nodal-portada');
    const nodalautor = document.getElementById('nodal-autor');
    const nodaldescripcion = document.getElementById('nodal-descripcion');

    nodaltitulo.textContent = libro.producto;
    nodalautor.textContent = libro.precio;
    nodaldescripcion.textContent = libro.categoria;
    nodalportada.src = `./img/${libro.imagen}`;
    nodalportada.alt = `imagen articulo`;

    nodal.style.display = 'block';

    const cerrarnodal = document.getElementById('cerrar-nodal');
    cerrarnodal.addEventListener("click", () => {
        nodal.style.display = 'none';
    });

    window.addEventListener("click", (event) => {
        if (event.target === nodal) {
            nodal.style.display = 'none';
        }
    });

}

window.onload = cargarLibros;